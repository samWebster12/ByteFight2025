import math
import random
from collections.abc import Callable

from game import player_board
from game.enums import Action

class PlayerController:
    def __init__(self, time_left: Callable):
        self.time_left = time_left
        self.lookahead_depth = 5  # We can do up to 10 steps. This is large!

    def bid(self, board: player_board.PlayerBoard, time_left: Callable):
        return 0

    def play(self, board: player_board.PlayerBoard, time_left: Callable):
        phase = self.determine_phase(board)

        moves = board.get_possible_directions()
        valid_moves = [m for m in moves if board.is_valid_move(m)]
        if not valid_moves:
            return [Action.FF]

        # Instead of a 1-step “has_future_move,” do a multi-step “can_survive.”
        safe_moves = []
        for mv in valid_moves:
            next_board, valid = board.forecast_turn([mv], check_validity=True)
            if not valid:
                continue
            if self.is_losing_state(next_board):
                continue
            # Now do a multi-step check up to 'self.lookahead_depth'
            if self.can_survive(next_board, self.lookahead_depth):
                safe_moves.append(mv)

        if not safe_moves:
            # if none pass the multi-step test, fallback
            return [random.choice(valid_moves)]

        if phase == "FARMING":
            chosen = self.farming_phase(board, safe_moves)
        else:
            chosen = self.defense_phase(board, safe_moves)

        return [chosen]

    # -------------------------------------------------------------------------
    # Phase Decision
    # -------------------------------------------------------------------------
    def determine_phase(self, board: player_board.PlayerBoard) -> str:
        my_apples = board.get_apples_eaten()
        enemy_apples = board.get_apples_eaten(enemy=True)
        my_len = board.get_length()
        min_size = board.get_min_player_size()

        if (my_apples < enemy_apples) or (my_len <= min_size + 2):
            return "FARMING"
        else:
            return "DEFENSE"

    # -------------------------------------------------------------------------
    # Farming / Defense
    # -------------------------------------------------------------------------
    def farming_phase(self, board: player_board.PlayerBoard, safe_moves: list[Action]) -> Action:
        apples = board.get_current_apples()
        if apples.size == 0:
            return random.choice(safe_moves)

        head = board.get_head_location()
        nearest_apple = None
        nearest_dist = 999999
        for ax, ay in apples:
            dist = abs(ax - head[0]) + abs(ay - head[1])
            if dist < nearest_dist:
                nearest_dist = dist
                nearest_apple = (ax, ay)

        best_move = None
        best_dist = nearest_dist
        for mv in safe_moves:
            next_board, valid = board.forecast_turn([mv], check_validity=True)
            if not valid:
                continue
            new_head = next_board.get_head_location()
            dist_new = abs(nearest_apple[0] - new_head[0]) + abs(nearest_apple[1] - new_head[1])
            if dist_new < best_dist:
                best_move = mv
                best_dist = dist_new

        if best_move is None:
            return random.choice(safe_moves)
        return best_move

    def defense_phase(self, board: player_board.PlayerBoard, safe_moves: list[Action]) -> Action:
        return random.choice(safe_moves)

    # -------------------------------------------------------------------------
    # Multi-Step Survival Check
    # -------------------------------------------------------------------------
    def can_survive(self, board: player_board.PlayerBoard, depth: int) -> bool:
        """
        Returns True if there's a sequence of moves (yours) leading to survival 
        at least for 'depth' total steps (yours + opponent's turns).
        
        We'll handle worst-case for the opponent: if there's ANY move the opponent
        can make that kills you for sure, we treat it as death. 
        If you can find at least one line of moves for you that avoids losing, 
        it might return True.
        
        Potentially expensive for large boards or big depth.
        """
        # 1) Base cases
        if depth <= 0:
            # Survived this long => good enough
            return True
        if self.is_losing_state(board):
            return False

        if board.is_my_turn():
            # 2) If it's your turn, see if ANY of your moves can keep you alive
            my_valid = []
            possible = board.get_possible_directions()
            for m in possible:
                if board.is_valid_move(m):
                    my_valid.append(m)

            if not my_valid:
                return False  # no moves => stuck

            # If at least 1 leads to survival, we can survive
            for mv in my_valid:
                nxt, ok = board.forecast_turn([mv], check_validity=True)
                if not ok:
                    continue
                if self.is_losing_state(nxt):
                    continue
                if self.can_survive(nxt, depth - 1):
                    return True
            return False
        else:
            # 3) It's the opponent's turn. We do a “worst case” approach:
            # if the opponent has ANY move that kills us, we are effectively dead.
            # Actually for a true minimax, you'd say if the opponent has a forced kill, we lose.
            # So we only survive if we can survive ALL possible opponent moves (i.e., no forced kills).
            # If you want "ANY move can kill us => we label as dead," you'd do the opposite.
            # Common approach in a 2p adversarial game: if the enemy can choose a move that kills you,
            # then you do not survive. So let's do that approach here.

            # Flip perspective
            bcopy = board.get_copy()
            bcopy.reverse_perspective()
            opp_valid = []
            possible = bcopy.get_possible_directions(enemy=False)  # from enemy perspective
            for m in possible:
                if bcopy.is_valid_move(m, enemy=False):
                    opp_valid.append(m)

            if not opp_valid:
                # Opponent can't move => might be good for us => we survive
                return True

            # If the enemy can choose a move that leads to you eventually dying no matter what,
            # we are dead. So if ANY move of the enemy leads to can_survive(...) = False, we must say "False."
            # Or the other approach: if ALL moves of the enemy lead to death => then we are definitely dead.
            #
            # In typical minimax "worst case," if the enemy has ANY move that kills us, we are dead.
            # So let's do that approach:
            for em in opp_valid:
                opp_board, ok = board.forecast_turn([em], check_validity=True)
                if not ok:
                    # might skip or treat as a valid kill?
                    continue
                if self.is_losing_state(opp_board):
                    # They kill us immediately => we are done
                    return False
                # If they don't kill us immediately, we still see if we eventually survive
                if not self.can_survive(opp_board, depth - 1):
                    # means the enemy can force a path to kill us => we can't survive
                    return False

            # If we can't find ANY move that kills us => we survive
            return True

    # -------------------------------------------------------------------------
    # is_losing_state / etc
    # -------------------------------------------------------------------------
    def get_safe_moves(self, board: player_board.PlayerBoard, moves: list[Action]) -> list[Action]:
        safe = []
        for mv in moves:
            next_board, valid = board.forecast_turn([mv], check_validity=True)
            if not valid:
                continue
            if self.is_losing_state(next_board):
                continue
            # Replace the old "has_future_move" with the deep check
            if self.can_survive(next_board, self.lookahead_depth):
                safe.append(mv)
        return safe

    def is_losing_state(self, board: player_board.PlayerBoard) -> bool:
        if board.is_game_over():
            return True
        my_len = board.get_length()
        min_len = board.get_min_player_size()
        return (my_len < min_len)

    def has_future_move(self, board: player_board.PlayerBoard) -> bool:
        """
        Old code, not used if we're doing deep checks. 
        Could be replaced by can_survive(board, 2).
        """
        if board.is_my_turn():
            possible = board.get_possible_directions()
            for m in possible:
                if board.is_valid_move(m):
                    return True
            return False
        return True